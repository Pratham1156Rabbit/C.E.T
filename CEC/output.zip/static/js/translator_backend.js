document.addEventListener('DOMContentLoaded', function() {
    const codeInput = document.getElementById('code-input');
    const translateBtn = document.getElementById('translate-btn');
    const translationOutput = document.getElementById('translation-output');
    const sourceLanguage = document.getElementById('source-language');
    const targetLanguage = document.getElementById('target-language');

    translateBtn.addEventListener('click', function() {
        const code = codeInput.value.trim();
        const sourceLang = sourceLanguage.value;
        const targetLang = targetLanguage.value;

        if (!code) {
            alert('Please enter some code to translate.');
            return;
        }

        if (sourceLang === targetLang) {
            alert('Source and target languages are the same. Please select different languages.');
            return;
        }

        // Show loading state
        translationOutput.innerHTML = '<p class="loading">Translating your code</p>';

        // Normally, we would make an AJAX request to the Django backend
        // But since we're using a direct approach, we'll invoke the Python script directly
        // using the fetch API to a simple proxy endpoint

        // Since we don't have a backend server running, we'll simulate the API call with a fallback
        try {
            // First try to call our Python script directly using Google Gemini API
            callGeminiAPI(code, sourceLang, targetLang)
                .then(translation => {
                    translationOutput.innerHTML = formatTranslation(translation);
                })
                .catch(error => {
                    translationOutput.innerHTML = `<p class="error">Error: ${error.message}</p>`;
                });
        } catch (error) {
            translationOutput.innerHTML = `<p class="error">Error: ${error.message}</p>`;
        }
    });

    async function callGeminiAPI(code, sourceLang, targetLang) {
        try {
            // In a real implementation, we would make an API call to our Django backend
            // For now, we'll use the Gemini API directly from the frontend (for demo purposes)

            // NOTE: In a production environment, you should NEVER expose your API key in frontend code
            // This is just for demonstration purposes
            const API_KEY = 'AIzaSyDlPz6y3UzJcCMB4Dpc6cpkdFPkKoJDJLY';
            const MODEL = 'gemini-1.5-flash';
            const API_URL = `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent?key=${API_KEY}`;

            const prompt = `
                Translate the following ${sourceLang} code to ${targetLang}:

                \`\`\`${sourceLang}
                ${code}
                \`\`\`

                Provide ONLY the translated code in ${targetLang} without any explanations, comments, or notes.
                Just the translated code, properly formatted.
            `;

            const response = await fetch(API_URL, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    contents: [
                        {
                            parts: [
                                { text: prompt }
                            ]
                        }
                    ]
                })
            });

            if (!response.ok) {
                throw new Error('API request failed');
            }

            const data = await response.json();

            // Extract the translation from the response
            if (data.candidates && data.candidates[0] && data.candidates[0].content && data.candidates[0].content.parts) {
                let translation = data.candidates[0].content.parts[0].text;

                // Clean up the response - sometimes the model includes markdown code blocks
                translation = translation.replace(/```[\w]*\n/g, '').replace(/```/g, '').trim();

                return translation;
            } else {
                throw new Error('Unexpected API response format');
            }
        } catch (error) {
            console.error('Error calling Gemini API:', error);

            // Fallback to a simple translation (in case the API call fails)
            return `Unable to call the Gemini API. Please ensure your internet connection is working and try again.

Error details: ${error.message}`;
        }
    }

    function formatTranslation(translation) {
        // Format the translation as a code block
        return `<pre><code>${escapeHtml(translation)}</code></pre>`;
    }

    function escapeHtml(unsafe) {
        return unsafe
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }
});
